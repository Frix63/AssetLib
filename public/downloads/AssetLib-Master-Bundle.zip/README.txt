ASSETLIB MASTER VECTOR BUNDLE
==============================
Total Assets: 2,366 Curated Procedural Vector SVGs
License: Creative Commons Zero (CC0 1.0 Universal)
Website: https://assetlib.dev

100% Free for personal and commercial projects. No attribution required.

Categories Included:
- 01_y2k_cyber_stars (Y2K Cyber Stars & Lens Sparkles)
- 02_brutalist_hud (Brutalist HUD Reticles & Target Dials)
- 03_acid_cyber_sigils (Acid Graphics & Cyber Sigils)
- 04_bauhaus_swiss (Bauhaus & Swiss Modernist Geometries)
- 05_organic_botanical (Fluid Blobs & Botanical Leaves)
- 06_retro_groovy (70s Retro Groovy Pop & Badges)
- 07_memphis_pop (Memphis 80s Postmodern Accents)
- 08_badges_seals (Award Seals, Stamps & Ribbons)
- 09_arrows_accents (Brutalist Arrows & Accents)
- 10_sacred_guilloche (Sacred Geometry & Guilloche Spirals)
- 11_halftones (Halftone Dot Screens & Matrices)
- 12_abstract_distortions (Wave Distortions & String Art)

Created with AssetLib (https://assetlib.dev).
